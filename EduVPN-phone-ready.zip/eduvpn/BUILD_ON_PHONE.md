# Build the APK from your phone

This project has been prepared for a GitHub Actions cloud build, so you do not need a laptop.

1. Create a GitHub repository and upload the contents of this project.
2. Open the repository's **Actions** tab.
3. Select **Build Android APK** and tap **Run workflow**.
4. Wait for the build to finish.
5. Open the completed workflow run and download **EduVPN-debug-apk** from Artifacts.
6. Extract the downloaded ZIP and install the APK on your Android phone.

## Gemini AI key (optional)

The app can build without a Gemini key and use its local fallback. To enable Gemini features, add a GitHub Actions repository secret named `GEMINI_API_KEY` containing your API key before running the workflow.

**Security note:** this project currently packages the Gemini key into the APK when configured. Treat any client-side API key as potentially extractable; for a production app, use a backend/proxy rather than shipping a secret in the APK.
