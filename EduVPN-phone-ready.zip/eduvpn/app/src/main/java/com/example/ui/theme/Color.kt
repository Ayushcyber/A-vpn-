package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val JarvisCyan = Color(0xFF00F0FF)
val ArcReactorBlue = Color(0xFF00A8FF)
val HologramPurple = Color(0xFF9D4EDD)
val NeonBlue = Color(0xFF1B9AAA)
val DeepObsidian = Color(0xFF050B14)
val SurfaceDark = Color(0xFF0D1B2A)
val SurfaceCardDark = Color(0xFF1B263B)
val BorderGlass = Color(0x3300F0FF)

val TextPrimary = Color(0xFFE0E1DD)
val TextSecondary = Color(0xFF778DA9)
val TextCyan = Color(0xFF00F0FF)

val AlertAmber = Color(0xFFFFB703)
val AlertRed = Color(0xFFFF0054)
val ActiveEmerald = Color(0xFF00F5D4)
