package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.JarvisHomeScreen
import com.example.ui.screens.MemoryScreen
import com.example.ui.screens.PermissionCenterScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.DeepObsidian
import com.example.ui.theme.JarvisTheme
import com.example.ui.viewmodel.JarvisViewModel

enum class ScreenRoute {
    HOME,
    PERMISSIONS,
    MEMORY,
    SETTINGS
}

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            JarvisTheme {
                val factory = JarvisViewModel.Factory(application)
                val viewModel: JarvisViewModel = viewModel(factory = factory)

                JarvisAppNavigation(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun JarvisAppNavigation(viewModel: JarvisViewModel) {
    var currentRoute by remember { mutableStateOf(ScreenRoute.HOME) }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = DeepObsidian
    ) { innerPadding ->
        val modifier = Modifier.padding(innerPadding)

        when (currentRoute) {
            ScreenRoute.HOME -> JarvisHomeScreen(
                viewModel = viewModel,
                onNavigatePermissions = { currentRoute = ScreenRoute.PERMISSIONS },
                onNavigateMemory = { currentRoute = ScreenRoute.MEMORY },
                onNavigateSettings = { currentRoute = ScreenRoute.SETTINGS },
                modifier = modifier
            )
            ScreenRoute.PERMISSIONS -> PermissionCenterScreen(
                onBack = { currentRoute = ScreenRoute.HOME },
                modifier = modifier
            )
            ScreenRoute.MEMORY -> MemoryScreen(
                viewModel = viewModel,
                onBack = { currentRoute = ScreenRoute.HOME },
                modifier = modifier
            )
            ScreenRoute.SETTINGS -> SettingsScreen(
                viewModel = viewModel,
                onBack = { currentRoute = ScreenRoute.HOME },
                modifier = modifier
            )
        }
    }
}
