package com.example.service

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

data class JarvisNotification(
    val packageName: String,
    val title: String,
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

class JarvisNotificationListenerService : NotificationListenerService() {

    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        sbn?.let {
            val extras = it.notification.extras
            val title = extras.getCharSequence("android.title")?.toString() ?: ""
            val text = extras.getCharSequence("android.text")?.toString() ?: ""
            val pkg = it.packageName ?: ""

            if (title.isNotBlank() || text.isNotBlank()) {
                val notif = JarvisNotification(pkg, title, text)
                _latestNotifications.value = (_latestNotifications.value + notif).takeLast(20)
            }
        }
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        instance = null
    }

    companion object {
        var instance: JarvisNotificationListenerService? = null
            private set

        private val _latestNotifications = MutableStateFlow<List<JarvisNotification>>(emptyList())
        val latestNotifications: StateFlow<List<JarvisNotification>> = _latestNotifications
    }
}
