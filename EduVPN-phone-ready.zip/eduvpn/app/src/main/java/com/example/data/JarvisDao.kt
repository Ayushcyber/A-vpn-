package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface JarvisDao {
    // Memory
    @Query("SELECT * FROM jarvis_memory ORDER BY timestamp DESC")
    fun getAllMemories(): Flow<List<MemoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMemory(memory: MemoryEntity): Long

    @Query("DELETE FROM jarvis_memory WHERE id = :id")
    suspend fun deleteMemoryById(id: Long)

    @Query("SELECT * FROM jarvis_memory WHERE `key` LIKE '%' || :query || '%' OR `value` LIKE '%' || :query || '%'")
    suspend fun searchMemory(query: String): List<MemoryEntity>

    // Conversations
    @Query("SELECT * FROM jarvis_conversations ORDER BY timestamp DESC LIMIT 50")
    fun getRecentConversations(): Flow<List<ConversationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertConversation(conversation: ConversationEntity): Long

    @Query("DELETE FROM jarvis_conversations")
    suspend fun clearConversations()

    // Command History
    @Query("SELECT * FROM jarvis_command_history ORDER BY timestamp DESC LIMIT 30")
    fun getRecentCommandHistory(): Flow<List<CommandHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCommandHistory(command: CommandHistoryEntity): Long
}
