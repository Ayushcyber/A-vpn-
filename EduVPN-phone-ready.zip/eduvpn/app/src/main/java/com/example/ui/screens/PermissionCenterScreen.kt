package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Accessibility
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.service.JarvisAccessibilityService
import com.example.service.JarvisNotificationListenerService
import com.example.ui.theme.ActiveEmerald
import com.example.ui.theme.AlertAmber
import com.example.ui.theme.BorderGlass
import com.example.ui.theme.DeepObsidian
import com.example.ui.theme.JarvisCyan
import com.example.ui.theme.SurfaceCardDark
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

data class PermissionItem(
    val title: String,
    val description: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val isGranted: Boolean,
    val onRequest: () -> Unit
)

@Composable
fun PermissionCenterScreen(
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    var micGranted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
    }
    var contactsGranted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, android.Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED)
    }
    var callGranted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, android.Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED)
    }
    var smsGranted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, android.Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED)
    }

    val requestPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        micGranted = results[android.Manifest.permission.RECORD_AUDIO] ?: micGranted
        contactsGranted = results[android.Manifest.permission.READ_CONTACTS] ?: contactsGranted
        callGranted = results[android.Manifest.permission.CALL_PHONE] ?: callGranted
        smsGranted = results[android.Manifest.permission.SEND_SMS] ?: smsGranted
    }

    val isAccessibilityEnabled = JarvisAccessibilityService.instance != null
    val isNotificationListenerEnabled = JarvisNotificationListenerService.instance != null

    val permissionsList = listOf(
        PermissionItem(
            title = "Microphone Access",
            description = "Required to listen to your voice commands in Hindi, Hinglish, and English.",
            icon = Icons.Default.Mic,
            isGranted = micGranted,
            onRequest = {
                requestPermissionLauncher.launch(arrayOf(android.Manifest.permission.RECORD_AUDIO))
            }
        ),
        PermissionItem(
            title = "Accessibility Service",
            description = "Allows JARVIS to execute phone controls like Return Home, Back, and Screen Lock.",
            icon = Icons.Default.Accessibility,
            isGranted = isAccessibilityEnabled,
            onRequest = {
                val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
            }
        ),
        PermissionItem(
            title = "Notification Access",
            description = "Enables JARVIS to read incoming WhatsApp and SMS messages out loud.",
            icon = Icons.Default.Notifications,
            isGranted = isNotificationListenerEnabled,
            onRequest = {
                val intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
            }
        ),
        PermissionItem(
            title = "Contacts Permission",
            description = "Required to search contact names when placing calls or sending messages.",
            icon = Icons.Default.Contacts,
            isGranted = contactsGranted,
            onRequest = {
                requestPermissionLauncher.launch(arrayOf(android.Manifest.permission.READ_CONTACTS))
            }
        ),
        PermissionItem(
            title = "Phone Calling",
            description = "Allows JARVIS to initiate phone calls to specified contacts.",
            icon = Icons.Default.Call,
            isGranted = callGranted,
            onRequest = {
                requestPermissionLauncher.launch(arrayOf(android.Manifest.permission.CALL_PHONE))
            }
        ),
        PermissionItem(
            title = "SMS & Messaging",
            description = "Allows JARVIS to prepare and send text messages.",
            icon = Icons.Default.Sms,
            isGranted = smsGranted,
            onRequest = {
                requestPermissionLauncher.launch(arrayOf(android.Manifest.permission.SEND_SMS))
            }
        )
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DeepObsidian)
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack, modifier = Modifier.testTag("back_from_permissions_button")) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = JarvisCyan)
            }
            Text(
                text = "PERMISSION CENTER",
                color = Color.White,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
        }

        Text(
            text = "JARVIS needs these Android permissions to seamlessly control your phone.",
            color = TextSecondary,
            fontSize = 13.sp,
            modifier = Modifier.padding(start = 8.dp, bottom = 16.dp, top = 4.dp)
        )

        LazyColumn {
            items(permissionsList.size) { index ->
                val item = permissionsList[index]
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp)
                        .border(1.dp, BorderGlass, RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(containerColor = SurfaceCardDark)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = item.icon,
                            contentDescription = null,
                            tint = if (item.isGranted) ActiveEmerald else AlertAmber,
                            modifier = Modifier.padding(end = 12.dp)
                        )

                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = item.title,
                                    color = Color.White,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Icon(
                                    imageVector = if (item.isGranted) Icons.Default.CheckCircle else Icons.Default.Warning,
                                    contentDescription = null,
                                    tint = if (item.isGranted) ActiveEmerald else AlertAmber,
                                    modifier = Modifier.height(14.dp)
                                )
                            }
                            Text(
                                text = item.description,
                                color = TextSecondary,
                                fontSize = 12.sp,
                                lineHeight = 16.sp,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }

                        if (!item.isGranted) {
                            Button(
                                onClick = item.onRequest,
                                colors = ButtonDefaults.buttonColors(containerColor = JarvisCyan, contentColor = DeepObsidian),
                                modifier = Modifier
                                    .padding(start = 8.dp)
                                    .testTag("grant_permission_btn_${index}")
                            ) {
                                Text("Grant", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}
