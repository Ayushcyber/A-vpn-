package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ActiveEmerald
import com.example.ui.theme.AlertRed
import com.example.ui.theme.ArcReactorBlue
import com.example.ui.theme.DeepObsidian
import com.example.ui.theme.HologramPurple
import com.example.ui.theme.JarvisCyan
import com.example.ui.viewmodel.AssistantState

@Composable
fun JarvisOrb(
    state: AssistantState,
    audioLevel: Float, // 0.0 to 1.0
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    orbSize: Dp = 220.dp
) {
    val infiniteTransition = rememberInfiniteTransition(label = "orb_rotation")

    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 6000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val primaryColor = when (state) {
        AssistantState.LISTENING -> JarvisCyan
        AssistantState.THINKING -> HologramPurple
        AssistantState.EXECUTING -> ActiveEmerald
        AssistantState.ERROR -> AlertRed
        AssistantState.COMPLETED -> ArcReactorBlue
        AssistantState.IDLE -> JarvisCyan
    }

    val stateText = when (state) {
        AssistantState.LISTENING -> "LISTENING"
        AssistantState.THINKING -> "THINKING"
        AssistantState.EXECUTING -> "EXECUTING"
        AssistantState.ERROR -> "ERROR"
        AssistantState.COMPLETED -> "JARVIS"
        AssistantState.IDLE -> "TAP TO SPEAK"
    }

    Box(
        modifier = modifier
            .size(orbSize)
            .clip(CircleShape)
            .clickable { onClick() }
            .testTag("jarvis_orb_button"),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2, size.height / 2)
            val baseRadius = (size.minDimension / 2) * 0.7f
            val dynamicRadius = baseRadius + (audioLevel * 30.dp.toPx()) * pulseScale

            // Outer Radial Glow
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        primaryColor.copy(alpha = 0.45f),
                        primaryColor.copy(alpha = 0.15f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = dynamicRadius * 1.35f
                ),
                radius = dynamicRadius * 1.35f,
                center = center
            )

            // Inner Core Glow
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color.White,
                        primaryColor,
                        DeepObsidian
                    ),
                    center = center,
                    radius = dynamicRadius * 0.7f
                ),
                radius = dynamicRadius * 0.65f,
                center = center
            )

            // Animated Outer Arc Reactor Ring 1
            drawCircle(
                color = primaryColor.copy(alpha = 0.8f),
                radius = dynamicRadius,
                center = center,
                style = Stroke(
                    width = 4.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(40f, 20f, 10f, 20f), rotationAngle)
                )
            )

            // Outer Ring 2 (Counter rotating effect)
            drawCircle(
                color = primaryColor.copy(alpha = 0.5f),
                radius = dynamicRadius * 1.15f,
                center = center,
                style = Stroke(
                    width = 2.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(20f, 30f), -rotationAngle * 1.5f)
                )
            )
        }

        // Central State Label
        Text(
            text = stateText,
            color = Color.White,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 2.sp,
            modifier = Modifier.padding(top = 4.dp)
        )
    }
}
