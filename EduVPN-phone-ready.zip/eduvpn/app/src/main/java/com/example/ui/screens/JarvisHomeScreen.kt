package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.ConfirmationDialog
import com.example.ui.components.JarvisOrb
import com.example.ui.theme.ActiveEmerald
import com.example.ui.theme.AlertRed
import com.example.ui.theme.BorderGlass
import com.example.ui.theme.DeepObsidian
import com.example.ui.theme.HologramPurple
import com.example.ui.theme.JarvisCyan
import com.example.ui.theme.SurfaceCardDark
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.AssistantState
import com.example.ui.viewmodel.JarvisViewModel

data class QuickAction(
    val label: String,
    val command: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
)

@Composable
fun JarvisHomeScreen(
    viewModel: JarvisViewModel,
    onNavigatePermissions: () -> Unit,
    onNavigateMemory: () -> Unit,
    onNavigateSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val assistantState by viewModel.assistantState.collectAsState()
    val statusText by viewModel.statusText.collectAsState()
    val userQuery by viewModel.userQuery.collectAsState()
    val responseText by viewModel.jarvisResponseText.collectAsState()
    val audioLevel by viewModel.audioLevel.collectAsState()
    val pendingConfirmation by viewModel.pendingConfirmation.collectAsState()

    var textInput by remember { mutableStateOf("") }

    val quickActions = remember {
        listOf(
            QuickAction("Torch On", "Turn on flashlight", Icons.Default.FlashOn),
            QuickAction("Volume Max", "Volume full karo", Icons.Default.VolumeUp),
            QuickAction("Lock Screen", "Lock screen", Icons.Default.Lock),
            QuickAction("Go Home", "Go to home screen", Icons.Default.Home),
            QuickAction("WhatsApp", "WhatsApp message to Papa saying reach home", Icons.Default.Send),
            QuickAction("Settings", "Open settings", Icons.Default.Settings)
        )
    }

    pendingConfirmation?.let { pending ->
        ConfirmationDialog(
            title = pending.title,
            description = pending.description,
            onConfirm = { viewModel.confirmPendingAction() },
            onCancel = { viewModel.cancelPendingAction() }
        )
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(DeepObsidian)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(if (assistantState == AssistantState.ERROR) AlertRed else ActiveEmerald)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "JARVIS v3.5",
                        color = JarvisCyan,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                }

                Row {
                    IconButton(
                        onClick = onNavigatePermissions,
                        modifier = Modifier.testTag("nav_permissions_button")
                    ) {
                        Icon(Icons.Default.Shield, contentDescription = "Permissions", tint = TextSecondary)
                    }
                    IconButton(
                        onClick = onNavigateMemory,
                        modifier = Modifier.testTag("nav_memory_button")
                    ) {
                        Icon(Icons.Default.Memory, contentDescription = "Memory", tint = TextSecondary)
                    }
                    IconButton(
                        onClick = onNavigateSettings,
                        modifier = Modifier.testTag("nav_settings_button")
                    ) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings", tint = TextSecondary)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Central Animated Orb
            JarvisOrb(
                state = assistantState,
                audioLevel = audioLevel,
                onClick = { viewModel.startListening() },
                orbSize = 210.dp
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Status Badge
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(SurfaceDark)
                    .border(1.dp, BorderGlass, RoundedCornerShape(20.dp))
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                Text(
                    text = statusText,
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // User Query & Response Transcript Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderGlass, RoundedCornerShape(16.dp))
                    .testTag("transcript_card"),
                colors = CardDefaults.cardColors(containerColor = SurfaceCardDark),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    if (userQuery.isNotBlank()) {
                        Text(
                            text = "YOU SAID:",
                            color = HologramPurple,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "\"$userQuery\"",
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(top = 2.dp, bottom = 12.dp)
                        )
                    }

                    Text(
                        text = "JARVIS:",
                        color = JarvisCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = responseText,
                        color = TextPrimary,
                        fontSize = 15.sp,
                        lineHeight = 22.sp,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Quick Action Chips Horizontal List
            Text(
                text = "QUICK VOICE COMMANDS",
                color = TextSecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
            )

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(quickActions) { action ->
                    AssistChip(
                        onClick = { viewModel.processUserQuery(action.command) },
                        label = { Text(action.label, color = TextPrimary, fontSize = 12.sp) },
                        leadingIcon = {
                            Icon(
                                imageVector = action.icon,
                                contentDescription = null,
                                tint = JarvisCyan,
                                modifier = Modifier.size(16.dp)
                            )
                        },
                        colors = AssistChipDefaults.assistChipColors(containerColor = SurfaceCardDark),
                        border = AssistChipDefaults.assistChipBorder(borderColor = BorderGlass, enabled = true)
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Fallback Text Input Dock
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = textInput,
                    onValueChange = { textInput = it },
                    placeholder = { Text("Type command (Hindi/English)...", color = TextSecondary, fontSize = 13.sp) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("text_command_input"),
                    shape = RoundedCornerShape(24.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = SurfaceDark,
                        unfocusedContainerColor = SurfaceDark,
                        focusedBorderColor = JarvisCyan,
                        unfocusedBorderColor = BorderGlass,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    maxLines = 1
                )

                Spacer(modifier = Modifier.width(8.dp))

                IconButton(
                    onClick = {
                        if (textInput.isNotBlank()) {
                            viewModel.processUserQuery(textInput)
                            textInput = ""
                        } else {
                            viewModel.startListening()
                        }
                    },
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(if (assistantState == AssistantState.LISTENING) AlertRed else JarvisCyan)
                        .testTag("submit_command_button")
                ) {
                    Icon(
                        imageVector = if (textInput.isNotBlank()) Icons.Default.Send else if (assistantState == AssistantState.LISTENING) Icons.Default.MicOff else Icons.Default.Mic,
                        contentDescription = "Send or Record",
                        tint = DeepObsidian
                    )
                }
            }
        }
    }
}
