package com.example.engine

import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class AIEngine {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    private val systemPrompt = """
        You are JARVIS, a voice-first intelligent AI assistant for an Android phone.
        You understand English, Hindi, and Hinglish commands (e.g., "Rahul ko call karo", "Turn on flashlight", "Torch on karo", "WhatsApp message to Papa saying reach home", "Volume 100% karo", "Lock screen").

        You must analyze the user command and return ONLY a valid JSON object matching this structure:
        {
          "actionType": "OPEN_APP" | "GO_HOME" | "OPEN_SETTINGS" | "VOLUME_CHANGE" | "FLASHLIGHT" | "LOCK_SCREEN" | "CALL_CONTACT" | "SEND_SMS" | "WHATSAPP_MSG" | "MEMORY_STORE" | "MEMORY_QUERY" | "GENERAL_TALK" | "UNKNOWN",
          "spokenResponse": "Brief natural response to speak back in the same language as user prompt",
          "targetApp": "App name if applicable",
          "contactName": "Contact name if calling or messaging",
          "phoneNumber": "Phone number if provided",
          "messageText": "Message content for SMS or WhatsApp",
          "settingName": "FLASHLIGHT_ON" | "FLASHLIGHT_OFF" | "VOLUME_UP" | "VOLUME_DOWN" | "VOLUME_MAX" | "VOLUME_MUTE" | "WIFI_SETTINGS" | "BLUETOOTH_SETTINGS",
          "memoryKey": "Key if storing/querying memory",
          "memoryValue": "Value if storing memory",
          "requiresUserConfirmation": true/false
        }

        Examples:
        Command: "Turn on flashlight" -> {"actionType":"FLASHLIGHT","settingName":"FLASHLIGHT_ON","spokenResponse":"Turning on flashlight, sir.","requiresUserConfirmation":false}
        Command: "Rahul ko call karo" -> {"actionType":"CALL_CONTACT","contactName":"Rahul","spokenResponse":"Calling Rahul. Please confirm.","requiresUserConfirmation":true}
        Command: "WhatsApp message to Papa saying I will be late" -> {"actionType":"WHATSAPP_MSG","contactName":"Papa","messageText":"I will be late","spokenResponse":"Preparing WhatsApp message for Papa.","requiresUserConfirmation":true}
        Command: "Volume full karo" -> {"actionType":"VOLUME_CHANGE","settingName":"VOLUME_MAX","spokenResponse":"Volume set to maximum.","requiresUserConfirmation":false}
        Command: "Remember my blood group is O positive" -> {"actionType":"MEMORY_STORE","memoryKey":"blood group","memoryValue":"O positive","spokenResponse":"I have stored your blood group as O positive, sir.","requiresUserConfirmation":false}
        Command: "What is my blood group?" -> {"actionType":"MEMORY_QUERY","memoryKey":"blood group","spokenResponse":"Checking memory...","requiresUserConfirmation":false}
    """.trimIndent()

    suspend fun parseUserCommand(userQuery: String, memoryContext: String = ""): ParsedJarvisResponse = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY

        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext fallbackLocalIntentParse(userQuery)
        }

        try {
            val promptText = if (memoryContext.isNotBlank()) {
                "User Memory Context:\n$memoryContext\n\nUser Voice Command: \"$userQuery\""
            } else {
                "User Voice Command: \"$userQuery\""
            }

            val requestJson = JSONObject().apply {
                put("contents", JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().put("text", promptText))
                        })
                    })
                })
                put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().put("text", systemPrompt))
                    })
                })
                put("generationConfig", JSONObject().apply {
                    put("responseMimeType", "application/json")
                    put("temperature", 0.2)
                })
            }

            val requestBody = requestJson.toString().toRequestBody("application/json".toMediaType())
            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"

            val httpRequest = Request.Builder()
                .url(url)
                .post(requestBody)
                .build()

            val response = client.newCall(httpRequest).execute()
            val responseBody = response.body?.string()

            if (response.isSuccessful && !responseBody.isNullOrBlank()) {
                val root = JSONObject(responseBody)
                val candidates = root.optJSONArray("candidates")
                if (candidates != null && candidates.length() > 0) {
                    val cand = candidates.getJSONObject(0)
                    val content = cand.optJSONObject("content")
                    val parts = content?.optJSONArray("parts")
                    val text = parts?.optJSONObject(0)?.optString("text")

                    if (!text.isNullOrBlank()) {
                        val parsedObj = JSONObject(text.trim())
                        return@withContext ParsedJarvisResponse(
                            actionType = parsedObj.optString("actionType", "GENERAL_TALK"),
                            spokenResponse = parsedObj.optString("spokenResponse", "Understood, sir."),
                            targetApp = parsedObj.optString("targetApp", null),
                            contactName = parsedObj.optString("contactName", null),
                            phoneNumber = parsedObj.optString("phoneNumber", null),
                            messageText = parsedObj.optString("messageText", null),
                            settingName = parsedObj.optString("settingName", null),
                            memoryKey = parsedObj.optString("memoryKey", null),
                            memoryValue = parsedObj.optString("memoryValue", null),
                            requiresUserConfirmation = parsedObj.optBoolean("requiresUserConfirmation", false)
                        )
                    }
                }
            }

            fallbackLocalIntentParse(userQuery)
        } catch (e: Exception) {
            e.printStackTrace()
            fallbackLocalIntentParse(userQuery)
        }
    }

    private fun fallbackLocalIntentParse(userQuery: String): ParsedJarvisResponse {
        val lower = userQuery.lowercase()

        return when {
            lower.contains("torch") || lower.contains("flashlight") || lower.contains("flash light") -> {
                if (lower.contains("off") || lower.contains("band")) {
                    ParsedJarvisResponse(
                        actionType = "FLASHLIGHT",
                        settingName = "FLASHLIGHT_OFF",
                        spokenResponse = "Turning flashlight off.",
                        requiresUserConfirmation = false
                    )
                } else {
                    ParsedJarvisResponse(
                        actionType = "FLASHLIGHT",
                        settingName = "FLASHLIGHT_ON",
                        spokenResponse = "Turning flashlight on.",
                        requiresUserConfirmation = false
                    )
                }
            }
            lower.contains("volume") -> {
                when {
                    lower.contains("full") || lower.contains("max") || lower.contains("100") -> ParsedJarvisResponse("VOLUME_CHANGE", "Setting volume to max.", settingName = "VOLUME_MAX")
                    lower.contains("mute") || lower.contains("silent") || lower.contains("zero") -> ParsedJarvisResponse("VOLUME_CHANGE", "Muting volume.", settingName = "VOLUME_MUTE")
                    lower.contains("down") || lower.contains("kam") -> ParsedJarvisResponse("VOLUME_CHANGE", "Reducing volume.", settingName = "VOLUME_DOWN")
                    else -> ParsedJarvisResponse("VOLUME_CHANGE", "Increasing volume.", settingName = "VOLUME_UP")
                }
            }
            lower.contains("home") || (lower.contains("screen") && lower.contains("go")) -> {
                ParsedJarvisResponse("GO_HOME", "Going to home screen.")
            }
            lower.contains("lock") -> {
                ParsedJarvisResponse("LOCK_SCREEN", "Locking device screen.", requiresUserConfirmation = false)
            }
            lower.contains("setting") || lower.contains("settings") -> {
                ParsedJarvisResponse("OPEN_SETTINGS", "Opening Android Settings.")
            }
            lower.contains("call") || lower.contains("phone") -> {
                val contactName = lower.replace("call", "").replace("phone", "").replace("karo", "").trim()
                ParsedJarvisResponse("CALL_CONTACT", "Calling ${contactName.ifBlank { "contact" }}.", contactName = contactName.ifBlank { null }, requiresUserConfirmation = true)
            }
            lower.contains("whatsapp") -> {
                ParsedJarvisResponse("WHATSAPP_MSG", "Opening WhatsApp.", targetApp = "WhatsApp", requiresUserConfirmation = true)
            }
            lower.contains("open") -> {
                val appName = lower.replace("open", "").replace("app", "").trim()
                ParsedJarvisResponse("OPEN_APP", "Opening $appName.", targetApp = appName)
            }
            else -> {
                ParsedJarvisResponse("GENERAL_TALK", "I am JARVIS, how can I help you today?")
            }
        }
    }
}
