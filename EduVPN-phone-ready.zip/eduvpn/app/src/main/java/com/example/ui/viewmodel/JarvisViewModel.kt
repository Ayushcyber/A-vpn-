package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.ConversationEntity
import com.example.data.JarvisDatabase
import com.example.data.MemoryEntity
import com.example.engine.AIEngine
import com.example.engine.ActionExecutor
import com.example.engine.ParsedJarvisResponse
import com.example.engine.SpeechRecognizerManager
import com.example.engine.TtsManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AssistantState {
    IDLE,
    LISTENING,
    THINKING,
    EXECUTING,
    COMPLETED,
    ERROR
}

data class PendingConfirmation(
    val action: ParsedJarvisResponse,
    val title: String,
    val description: String
)

class JarvisViewModel(application: Application) : AndroidViewModel(application) {

    private val db = JarvisDatabase.getDatabase(application)
    private val dao = db.jarvisDao()

    val aiEngine = AIEngine()
    val actionExecutor = ActionExecutor(application)
    val speechRecognizer = SpeechRecognizerManager(application)
    val ttsManager = TtsManager(application)

    private val _assistantState = MutableStateFlow(AssistantState.IDLE)
    val assistantState: StateFlow<AssistantState> = _assistantState

    private val _statusText = MutableStateFlow("Ready to assist, sir.")
    val statusText: StateFlow<String> = _statusText

    private val _userQuery = MutableStateFlow("")
    val userQuery: StateFlow<String> = _userQuery

    private val _jarvisResponseText = MutableStateFlow("I am JARVIS, your intelligent voice assistant.")
    val jarvisResponseText: StateFlow<String> = _jarvisResponseText

    private val _pendingConfirmation = MutableStateFlow<PendingConfirmation?>(null)
    val pendingConfirmation: StateFlow<PendingConfirmation?> = _pendingConfirmation

    val isListening = speechRecognizer.isListening
    val audioLevel = speechRecognizer.audioLevel
    val isSpeaking = ttsManager.isSpeaking

    val conversationList: StateFlow<List<ConversationEntity>> = dao.getRecentConversations()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val memoryList: StateFlow<List<MemoryEntity>> = dao.getAllMemories()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun startListening(languageCode: String = "hi-IN") {
        if (_assistantState.value == AssistantState.LISTENING) {
            speechRecognizer.stopListening()
            _assistantState.value = AssistantState.IDLE
            return
        }

        _assistantState.value = AssistantState.LISTENING
        _statusText.value = "Listening to voice input..."
        _userQuery.value = ""

        speechRecognizer.startListening(
            languageCode = languageCode,
            onResult = { query ->
                _userQuery.value = query
                processUserQuery(query)
            },
            onError = { error ->
                _assistantState.value = AssistantState.ERROR
                _statusText.value = error
                ttsManager.speak("Sorry, $error")
            }
        )
    }

    fun stopListening() {
        speechRecognizer.stopListening()
        _assistantState.value = AssistantState.IDLE
        _statusText.value = "Ready to assist, sir."
    }

    fun processUserQuery(query: String) {
        if (query.isBlank()) return

        viewModelScope.launch {
            _assistantState.value = AssistantState.THINKING
            _statusText.value = "Processing command..."

            // Save user message to Room DB
            dao.insertConversation(
                ConversationEntity(sender = "USER", text = query, assistantState = "THINKING")
            )

            // Gather memory context
            val currentMemories = memoryList.value
            val memoryContext = currentMemories.joinToString("; ") { "${it.key}: ${it.value}" }

            val parsed = aiEngine.parseUserCommand(query, memoryContext)

            if (parsed.actionType == "MEMORY_STORE" && !parsed.memoryKey.isNullOrBlank() && !parsed.memoryValue.isNullOrBlank()) {
                dao.insertMemory(MemoryEntity(key = parsed.memoryKey, value = parsed.memoryValue))
            } else if (parsed.actionType == "MEMORY_QUERY" && !parsed.memoryKey.isNullOrBlank()) {
                val matches = dao.searchMemory(parsed.memoryKey)
                val answer = if (matches.isNotEmpty()) {
                    "In memory: ${matches.first().key} is ${matches.first().value}"
                } else {
                    "No memory record found for ${parsed.memoryKey}."
                }
                speakAndFinish(answer)
                return@launch
            }

            if (parsed.requiresUserConfirmation) {
                _assistantState.value = AssistantState.THINKING
                _pendingConfirmation.value = PendingConfirmation(
                    action = parsed,
                    title = "Confirm Sensitive Action",
                    description = "${parsed.spokenResponse}\nDo you want JARVIS to execute this request?"
                )
                ttsManager.speak(parsed.spokenResponse)
            } else {
                executeParsedAction(parsed)
            }
        }
    }

    fun confirmPendingAction() {
        val pending = _pendingConfirmation.value ?: return
        _pendingConfirmation.value = null
        viewModelScope.launch {
            executeParsedAction(pending.action)
        }
    }

    fun cancelPendingAction() {
        _pendingConfirmation.value = null
        _assistantState.value = AssistantState.IDLE
        _statusText.value = "Action cancelled."
        ttsManager.speak("Action cancelled, sir.")
    }

    private suspend fun executeParsedAction(parsed: ParsedJarvisResponse) {
        _assistantState.value = AssistantState.EXECUTING
        _statusText.value = "Executing action..."

        val resultMsg = actionExecutor.executeAction(parsed)

        _jarvisResponseText.value = parsed.spokenResponse
        _assistantState.value = AssistantState.COMPLETED
        _statusText.value = resultMsg

        // Save JARVIS response to Room DB
        dao.insertConversation(
            ConversationEntity(sender = "JARVIS", text = parsed.spokenResponse, assistantState = "COMPLETED")
        )

        ttsManager.speak(parsed.spokenResponse) {
            _assistantState.value = AssistantState.IDLE
            _statusText.value = "Ready to assist, sir."
        }
    }

    private fun speakAndFinish(text: String) {
        _jarvisResponseText.value = text
        _assistantState.value = AssistantState.COMPLETED
        _statusText.value = text

        viewModelScope.launch {
            dao.insertConversation(
                ConversationEntity(sender = "JARVIS", text = text, assistantState = "COMPLETED")
            )
        }

        ttsManager.speak(text) {
            _assistantState.value = AssistantState.IDLE
            _statusText.value = "Ready to assist, sir."
        }
    }

    fun saveCustomMemory(key: String, value: String) {
        if (key.isBlank() || value.isBlank()) return
        viewModelScope.launch {
            dao.insertMemory(MemoryEntity(key = key, value = value))
        }
    }

    fun deleteMemory(id: Long) {
        viewModelScope.launch {
            dao.deleteMemoryById(id)
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            dao.clearConversations()
        }
    }

    override fun onCleared() {
        super.onCleared()
        speechRecognizer.destroy()
        ttsManager.destroy()
    }

    class Factory(private val application: Application) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return JarvisViewModel(application) as T
        }
    }
}
