package com.example.engine

data class ParsedJarvisResponse(
    val actionType: String, // OPEN_APP, CLOSE_APP, GO_HOME, OPEN_SETTINGS, VOLUME_CHANGE, FLASHLIGHT, LOCK_SCREEN, MEDIA_CONTROL, CALL_CONTACT, SEND_SMS, WHATSAPP_MSG, MEMORY_STORE, MEMORY_QUERY, GENERAL_TALK, UNKNOWN
    val spokenResponse: String,
    val targetApp: String? = null,
    val contactName: String? = null,
    val phoneNumber: String? = null,
    val messageText: String? = null,
    val settingName: String? = null,
    val memoryKey: String? = null,
    val memoryValue: String? = null,
    val requiresUserConfirmation: Boolean = false
)
