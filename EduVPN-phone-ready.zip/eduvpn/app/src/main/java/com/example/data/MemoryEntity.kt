package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "jarvis_memory")
data class MemoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val key: String,
    val value: String,
    val memoryType: String = "USER_PREF", // USER_PREF, CONTACT, REMINDER, SYSTEM_NOTE
    val timestamp: Long = System.currentTimeMillis()
)
