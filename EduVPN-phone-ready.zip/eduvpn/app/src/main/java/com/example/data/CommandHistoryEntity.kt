package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "jarvis_command_history")
data class CommandHistoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val userQuery: String,
    val parsedAction: String,
    val executionResult: String,
    val isSuccess: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)
