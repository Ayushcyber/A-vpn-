package com.example.engine

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.ContactsContract
import android.provider.Settings
import android.telephony.SmsManager
import android.widget.Toast
import com.example.service.JarvisAccessibilityService

class ActionExecutor(private val context: Context) {

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager

    fun executeAction(parsed: ParsedJarvisResponse): String {
        return try {
            when (parsed.actionType) {
                "FLASHLIGHT" -> handleFlashlight(parsed.settingName)
                "VOLUME_CHANGE" -> handleVolume(parsed.settingName)
                "GO_HOME" -> handleGoHome()
                "OPEN_SETTINGS" -> handleOpenSettings()
                "OPEN_APP" -> handleOpenApp(parsed.targetApp ?: "")
                "CALL_CONTACT" -> handleCall(parsed.phoneNumber, parsed.contactName)
                "SEND_SMS" -> handleSms(parsed.phoneNumber, parsed.contactName, parsed.messageText)
                "WHATSAPP_MSG" -> handleWhatsApp(parsed.contactName, parsed.messageText)
                "LOCK_SCREEN" -> handleLockScreen()
                else -> "Action performed."
            }
        } catch (e: Exception) {
            "Error executing action: ${e.message}"
        }
    }

    private fun handleFlashlight(settingName: String?): String {
        val enable = settingName == "FLASHLIGHT_ON" || settingName == null
        return try {
            val cameraId = cameraManager.cameraIdList.firstOrNull { id ->
                val chars = cameraManager.getCameraCharacteristics(id)
                chars.get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: cameraManager.cameraIdList[0]

            cameraManager.setTorchMode(cameraId, enable)
            if (enable) "Flashlight turned on." else "Flashlight turned off."
        } catch (e: Exception) {
            "Unable to access flashlight."
        }
    }

    private fun handleVolume(settingName: String?): String {
        val maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val currentVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)

        when (settingName) {
            "VOLUME_MAX" -> audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, maxVolume, AudioManager.FLAG_SHOW_UI)
            "VOLUME_MUTE" -> audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, 0, AudioManager.FLAG_SHOW_UI)
            "VOLUME_DOWN" -> audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, (currentVolume - 3).coerceAtLeast(0), AudioManager.FLAG_SHOW_UI)
            else -> audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, (currentVolume + 3).coerceAtMost(maxVolume), AudioManager.FLAG_SHOW_UI)
        }
        return "Volume adjusted."
    }

    private fun handleGoHome(): String {
        val service = JarvisAccessibilityService.instance
        return if (service != null && service.performHome()) {
            "Returned to home screen."
        } else {
            val intent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_HOME)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            "Returned to home screen."
        }
    }

    private fun handleOpenSettings(): String {
        val intent = Intent(Settings.ACTION_SETTINGS).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
        return "Opening Settings."
    }

    private fun handleOpenApp(appName: String): String {
        if (appName.isBlank()) return "Please specify an app name."

        val pm = context.packageManager
        val packages = pm.getInstalledApplications(0)

        val targetPkg = packages.firstOrNull { app ->
            val label = pm.getApplicationLabel(app).toString().lowercase()
            label.contains(appName.lowercase()) || app.packageName.lowercase().contains(appName.lowercase())
        }

        return if (targetPkg != null) {
            val launchIntent = pm.getLaunchIntentForPackage(targetPkg.packageName)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launchIntent)
                "Opening ${pm.getApplicationLabel(targetPkg)}."
            } else {
                "App launch intent unavailable."
            }
        } else {
            "App '$appName' not found on device."
        }
    }

    private fun handleCall(number: String?, name: String?): String {
        val phoneNum = number ?: findPhoneNumberByName(name)
        return if (!phoneNum.isNullOrBlank()) {
            val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$phoneNum")).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            try {
                context.startActivity(intent)
                "Initiating phone call to ${name ?: phoneNum}."
            } catch (e: Exception) {
                // Fallback to dialer if direct call permission not granted
                val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phoneNum")).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(dialIntent)
                "Opened phone dialer for ${name ?: phoneNum}."
            }
        } else {
            "Contact ${name ?: ""} not found."
        }
    }

    private fun handleSms(number: String?, name: String?, text: String?): String {
        val phoneNum = number ?: findPhoneNumberByName(name)
        val msg = text ?: "Hello from JARVIS"

        return if (!phoneNum.isNullOrBlank()) {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("sms:$phoneNum")).apply {
                putExtra("sms_body", msg)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            "Opening SMS composer for ${name ?: phoneNum}."
        } else {
            "Phone number missing for ${name ?: "recipient"}."
        }
    }

    private fun handleWhatsApp(name: String?, text: String?): String {
        val phoneNum = findPhoneNumberByName(name)
        val msg = text ?: "Hello"

        return try {
            if (!phoneNum.isNullOrBlank()) {
                val cleanNumber = phoneNum.replace("+", "").replace(" ", "").replace("-", "")
                val uri = Uri.parse("https://api.whatsapp.com/send?phone=$cleanNumber&text=${Uri.encode(msg)}")
                val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                    setPackage("com.whatsapp")
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
                "Opening WhatsApp chat with ${name ?: phoneNum}."
            } else {
                // Launch WhatsApp app directly
                val pm = context.packageManager
                val intent = pm.getLaunchIntentForPackage("com.whatsapp")
                if (intent != null) {
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(intent)
                    "Opened WhatsApp. Contact number not found for direct message."
                } else {
                    "WhatsApp is not installed on this device."
                }
            }
        } catch (e: Exception) {
            "Could not open WhatsApp: ${e.message}"
        }
    }

    private fun handleLockScreen(): String {
        val service = JarvisAccessibilityService.instance
        return if (service != null && service.performLockScreen()) {
            "Device screen locked."
        } else {
            "Screen lock requires enabling JARVIS Accessibility Service."
        }
    }

    private fun findPhoneNumberByName(name: String?): String? {
        if (name.isNullOrBlank()) return null

        return try {
            val cursor = context.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME),
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
                arrayOf("%$name%"),
                null
            )
            cursor?.use {
                if (it.moveToFirst()) {
                    val numIndex = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                    if (numIndex != -1) it.getString(numIndex) else null
                } else null
            }
        } catch (e: Exception) {
            null
        }
    }
}
