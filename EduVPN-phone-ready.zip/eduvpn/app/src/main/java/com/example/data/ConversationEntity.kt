package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "jarvis_conversations")
data class ConversationEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val sender: String, // "USER" or "JARVIS"
    val text: String,
    val assistantState: String = "COMPLETED", // LISTENING, THINKING, EXECUTING, COMPLETED, ERROR
    val timestamp: Long = System.currentTimeMillis()
)
